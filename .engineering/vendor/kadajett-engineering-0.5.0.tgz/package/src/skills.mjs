import { realpathSync } from "node:fs";
import { resolve } from "node:path";
import { managedBlock, save, saveJson, text } from "./files.mjs";
import { appendIgnores } from "./integrations.mjs";
import { directPackages, selectSkills, unmatchedPackages } from "./skills/catalog.mjs";
import { installSkills } from "./skills/install.mjs";
import { guidanceInstructions, selectGuidance } from "./skills/guidance.mjs";

const manifestPath = ".engineering/skills.json";

function storedSkills(root) {
	const content = text(root, manifestPath);
	if (!content) return { version: 1, skills: [] };
	const stored = JSON.parse(content);
	if (stored.version !== 1 || !Array.isArray(stored.skills))
		throw new Error(`Unsupported ${manifestPath}; preserve it and review before skill setup.`);
	for (const skill of stored.skills) {
		if (!skill || typeof skill.name !== "string" || !/^[a-f0-9]{40}$/.test(skill.revision))
			throw new Error(`Invalid pinned skill in ${manifestPath}`);
	}
	return stored;
}

function pinnedSelection(manifest, profile, stored) {
	const previous = new Map(stored.skills.map((skill) => [skill.name, skill]));
	return selectSkills(manifest, profile).map((skill) => {
		const pinned = previous.get(skill.name);
		if (pinned?.repository === skill.repository && pinned.path === skill.path)
			return { ...skill, revision: pinned.revision };
		return skill;
	});
}

export function skillPlan(root, profile) {
	const manifest = JSON.parse(text(root, "package.json") || "{}");
	const stored = storedSkills(root);
	const selectedProfile =
		profile ??
		stored.profile ??
		JSON.parse(text(root, ".engineering/state.json") || "{}").profile ??
		"generic";
	const skills = pinnedSelection(manifest, selectedProfile, stored);
	return {
		profile: selectedProfile,
		skills,
		guidance: selectGuidance(directPackages(manifest), selectedProfile, skills),
		unmatchedPackages: unmatchedPackages(manifest),
	};
}

function skillInstructions(plan) {
	const names = plan.skills.map((skill) => `\`${skill.name}\``).join(", ");
	return `## Project skills

These skills were picked for this project: ${names}.

- Before coding or reviewing, look in .agents/skills and read the relevant SKILL.md files. Use the shared engineering advice and matching library guidance without waiting for the user to ask.
- After cloning the project or changing dependencies, run engineering skills . (or the engineering:skills package script). It restores local links and picks guidance for newly added libraries.
- .engineering/skills.json records the upstream sources and fallback versions. Skills reused from your own installation stay yours; setup doesn't upgrade them.
- Follow the user's instructions and this project's architecture, checks, security rules, and agreed workflow when a skill suggests something different. A skill mentioning a script, plugin, MCP server, cloud resource, or deployment isn't permission to run or install it.
- Some libraries won't have a matching skill. Use their official docs rather than assuming they're covered.
${guidanceInstructions(plan.guidance)}`;
}

function managedInstructions(root, plan) {
	return new Map([
		["AGENTS.md", managedBlock(text(root, "AGENTS.md"), "skills", skillInstructions(plan))],
		[
			"CLAUDE.md",
			managedBlock(
				text(root, "CLAUDE.md"),
				"skills",
				"Read the project skill guidance in AGENTS.md and discover relevant skills in .claude/skills.",
			),
		],
		[
			".omp/AGENTS.md",
			managedBlock(
				text(root, ".omp/AGENTS.md"),
				"skills",
				"@../AGENTS.md\n\nDiscover project skills in skills/.",
			),
		],
	]);
}

function portableSkills(plan, installed) {
	return {
		version: 1,
		profile: plan.profile,
		managedLinks: installed.managedLinks,
		skills: installed.skills.map(
			({ name, repository, revision, path, reason, status, localDigest }) => ({
				name,
				repository,
				revision,
				path,
				reason,
				resolution: ["project", "local"].includes(status) ? status : "pinned-upstream",
				...(localDigest ? { localDigest } : {}),
			}),
		),
		unmatchedPackages: plan.unmatchedPackages,
		guidance: plan.guidance,
	};
}

function reportSkills(result, unmatched) {
	console.log(`Agent skills: ${result.skills.length} available.`);
	for (const skill of result.skills) console.log(`  ${skill.name}: ${skill.status}`);
	if (unmatched.length)
		console.log(
			`No matching library skill: ${unmatched.join(", ")}. Shared guidance and any listed official references still apply.`,
		);
}

export async function setupSkills(directory, profile, options = {}) {
	if (options.skills === false) return { skills: [], links: [], disabled: true };
	const root = realpathSync(resolve(directory));
	const plan = skillPlan(root, profile);
	const instructions = managedInstructions(root, plan);
	text(root, ".gitignore");
	const preview = await installSkills(root, plan.skills, { ...options, dryRun: true });
	if (options.dryRun) {
		console.log(JSON.stringify({ ...plan, installation: preview }, null, 2));
		return preview;
	}
	await appendIgnores(
		root,
		".gitignore",
		preview.links.map((path) => `/${path}`),
		"SKILLS",
	);
	const installed = await installSkills(root, plan.skills, options);
	for (const [path, content] of instructions) save(root, path, content);
	saveJson(root, manifestPath, portableSkills(plan, installed));
	reportSkills(installed, plan.unmatchedPackages);
	if (plan.guidance.length)
		console.log(
			`Official reference guidance: ${plan.guidance.map(({ title }) => title).join("; ")}.`,
		);
	return installed;
}
